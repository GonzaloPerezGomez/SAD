Como inicializar el programa:

        para entrenan un modelo:

            python plantillaPosibleDecisionTreesParaEGela.py -m train -f _____fichero csv_____ -p _____fichero json_____ -a _____-algoritmos a realizar_____


        para realizar el test de un modelo:

            python plantillaPosibleDecisionTreesParaEGela.py -m test -f _____fichero csv del test_____ -p _____fichero json_____ -a _____-algoritmos a realizar_____



        -v es para sacar las metricas por la terminal
        --debug es para guardar los datos despues del preproceso
